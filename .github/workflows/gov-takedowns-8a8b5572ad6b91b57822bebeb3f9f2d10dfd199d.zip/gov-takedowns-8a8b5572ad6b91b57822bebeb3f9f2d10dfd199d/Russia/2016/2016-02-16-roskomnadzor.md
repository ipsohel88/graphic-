«Добрый день!

В соответствии с требованием Генеральной прокуратуры № 27-31-2015/Ид1959-15
от 22.06.2015, информация, размещенная по URL адресу
https://github.com/Alex0007/crimea-ozpp/blob/master/README.md, содержит
призывы к осуществлению экстремистской деятельности. Согласно Федеральному
закону от 28.12.2013г. № 398-ФЗ, если владелец ресурса не удалит
запрещенную информацию, то будут приняты меры по ограничению доступа
(блокировке) на территории РФ к информационному ресурсу
https://github.com/Alex0007/crimea-ozpp/blob/master/README.md и его сетевым
адресам в соответствии с действующим законодательством.

Информирую Вас об этом.

Описание запрещенной информации: опубликована статья - «Памятка для
российских туристов, направляющихся на отдых в Крым», содержащая признаки
призывов к осуществлению действий, направленных на нарушение территориальной
целостности Российской Федерации.

Запрещенная информация размещена по URL:

- https://github.com/Alex0007/crimea-ozpp/blob/master/README.md

С уважением, Роскомнадзор

Hello,

In accordance with the Demand of the Office of the Russian Federation
Prosecutor General № 27-31-2015/Ид1959-15 dated 22.06.2015, the information
on the URL <https://github.com/Alex0007/crimea-ozpp/blob/master/README.md>
https://github.com/Alex0007/crimea-ozpp/blob/master/README.md contains the
appeals to the extremist activity

According to Federal Law №398 dated 28.12.2013 resource owner has to remove
prohibited information, otherwise the access to the following URL
<https://github.com/Alex0007/crimea-ozpp/blob/master/README.md>
https://github.com/Alex0007/crimea-ozpp/blob/master/README.md would be
limited.

We inform you about that.

Prohibited information: The article named “Memo to the Russian tourists
travelling to Krimea” containing appeals to the activities aimed at
violation of Russian Federation territorial integrity.

Thus, any dissemination of information about the organization, containing
signs of its propaganda is prohibited in the Russian Federation.

Prohibited information is located on

<https://github.com/Alex0007/crimea-ozpp/blob/master/README.md>
https://github.com/Alex0007/crimea-ozpp/blob/master/README.md

Best regards,

Federal Service for Supervision in the Sphere of Telecom, Information
Technologies and Mass Communications (Roskomnadzor).
