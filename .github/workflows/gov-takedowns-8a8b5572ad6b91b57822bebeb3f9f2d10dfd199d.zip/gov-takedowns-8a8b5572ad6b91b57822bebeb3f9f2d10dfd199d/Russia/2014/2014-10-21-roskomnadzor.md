Hello,

We should inform you that the URL

https://github.com/russian-suicide/ololo
https://github.com/muromec/blog/blob/d0a4b73064b0d2306a6184b75c9bbfeb3daa2a00/repost/suicide.rst
https://github.com/numitus/objidlib/blob/master/suicide.txt
https://github.com/samm-git/objidlib/blob/master/suicide.txt
https://github.com/l29ah/objidlib/blob/master/suicide.txt
https://github.com/Anakros/objidlib/blob/master/suicide.txt
https://github.com/kleonov/some-text/



contains information which has been recognized by Federal service on
customers' rights protection and human well-being surveillance
(ROSPOTREBNADZOR) as prohibited on the territory of the Russian Federation.

According to the Federal Law of July 27, 2006 № 149-FZ "On Information,
Information Technology and Information Security (
<http://eais.rkn.gov.ru/docs.eng/149.pdf>
http://eais.rkn.gov.ru/docs.eng/149.pdf) and the resolution of the
Government of the Russian Federation on October 26, 2012 № 1101 (
<http://eais.rkn.gov.ru/docs.eng/1101.pdf>
http://eais.rkn.gov.ru/docs.eng/1101.pdf) these URLs and their corresponding
IP address will be included to the "Unified register of domain names,
Internet web-site page links and network addresses enabling to identify the
Internet web-sites containing the information prohibited for public
distribution in the Russian Federation” and will be blocked by
communication operators on the territory of the Russian Federation.

Please inform us about the removal of information in the shortest time
possible.

Thank you for your cooperation!

---

Federal Service for Supervision in the Sphere of Telecom, Information
Technologies and Mass Communications (ROSKOMNADZOR).
