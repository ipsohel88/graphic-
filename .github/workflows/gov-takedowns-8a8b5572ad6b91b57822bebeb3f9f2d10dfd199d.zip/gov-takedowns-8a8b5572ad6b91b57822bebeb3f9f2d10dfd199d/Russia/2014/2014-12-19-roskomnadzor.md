Hello,

This is a message from The Federal Service for Supervision of
Communications, Information Technology, and Mass Media of the Russian
Federation.

We should inform you that the web-page:

https://github.com/IronKaput/sepulckis

contains information about ways to commit suicide, which previously has been
recognized by Federal service on customers' rights protection and human
well-being surveillance (ROSPOTREBNADZOR) as prohibited on the territory of
the Russian Federation

Also we send you links to legislation that regulates the functioning of the
"Unified register of domain names, Internet web-site page links and network
addresses enabling to identify the Internet web-sites containing the
information prohibited for public distribution in the Russian Federation":

- http://eais.rkn.gov.ru/docs.eng/149.pdf

- http://eais.rkn.gov.ru/docs.eng/1101.pdf

In addition, we must admit, that, according to GitHub`s Terms of Service
(https://help.github.com/articles/github-terms-of-service/), users of the
Servise are not allowed to use the Service for any illegal or unauthorized
purpose. They must not, in the use of the Service, violate any laws in their
jurisdiction (including but not limited to copyright or trademark laws).

And, due to GitHub's Terms of Service, GitHub confirms its possibility to
remove Content and Accounts containing Content that is unlawful, offensive,
threatening, libelous, defamatory, pornographic, obscene or otherwise
objectionable or violates any party's intellectual property or GitHub`s
Terms of Service.

So, please, remove the forbidden information and inform us about the removal
of this information in the shortest time possible.

Thank you for your cooperation!

---

Federal Service for Supervision of Communications, Information Technology,
and Mass Media (ROSKOMNADZOR)
